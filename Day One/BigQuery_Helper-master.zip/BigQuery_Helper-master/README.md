BigQuery_Helper provides a helper class to simplify common read-only BigQuery tasks.
It currently only works within kernels on [Kaggle](kaggle.com/) as it has no functionality for logging in to BigQuery.

You can see a working example in [this Kaggle kernel](https://www.kaggle.com/sohier/introduction-to-the-bq-helper-package/).
